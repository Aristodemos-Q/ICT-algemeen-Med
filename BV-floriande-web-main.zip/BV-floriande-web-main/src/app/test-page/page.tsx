'use client';

export default function TestPage() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Test Page</h1>
      <p>This is a simple test page to check if the server works properly.</p>
    </div>
  );
}
